<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <img src="../public/img/logo-curso.svg" width="100" height="100"  alt="logo-curso">
</svg>
