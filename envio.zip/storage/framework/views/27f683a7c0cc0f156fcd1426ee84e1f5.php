<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/js/utilities.js', 'resources/css/app.css']); ?>
    </head>

    <body class="grey lighten-5">

        <div class="navbar-fixed">
            <nav class="indigo darken-3">
                <div class="nav-wrapper">
                    
                    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </nav>
        </div>

        
        <?php if(auth()->guard()->check()): ?>
            <ul id="userDropdown" class="dropdown-content">
                <li><a href="<?php echo e(route('profile.edit')); ?>" class="indigo-text text-darken-3">Perfil</a></li>
                <li class="divider"></li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();" class="indigo-text text-darken-3">Sair</a>
                    </form>
                </li>
            </ul>
        <?php endif; ?>

        
        <ul class="sidenav" id="mobile-demo">
            
            <li><a href="<?php echo e(route('courses.index')); ?>" class="indigo-text text-darken-3">Cursos</a></li>
            <li><a href="<?php echo e(route('pages.about')); ?>" class="indigo-text text-darken-3">Sobre</a></li>

            <?php if(auth()->guard()->guest()): ?>
                <li class="divider"></li>
                <li><a href="<?php echo e(route('login')); ?>" class="indigo-text text-darken-3">Login</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="indigo-text text-darken-3">Registro</a></li>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <li class="divider"></li>
                <li><a href="<?php echo e(route('dashboard')); ?>" class="indigo-text text-darken-3">Dashboard</a></li>
                <li><a href="<?php echo e(route('profile.edit')); ?>" class="indigo-text text-darken-3">Perfil (<?php echo e(Auth::user()->name); ?>)</a></li>
                <li class="divider"></li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();" class="indigo-text text-darken-3">Sair</a>
                    </form>
                </li>
            <?php endif; ?>
        </ul>

        <div class="container"> 
            <?php echo $__env->yieldContent('content'); ?> 
        </div>

        <footer>
            <div class="indigo darken-3 white-text"> 
                <div class="">
                    <p>Copyright ©<span id="year-copyright"></span> Igreja Evangélica Assembleia de Deus Ministério do Belém</p>
                </div>
            </div>
        </footer>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <script>
            // Script para inicializar componentes do Materialize (ex: dropdowns, modais, etc.)
            document.addEventListener('DOMContentLoaded', function() {
                M.AutoInit();
            });
        </script>
        
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Plataforma_ADBelem\resources\views/layouts/app.blade.php ENDPATH**/ ?>