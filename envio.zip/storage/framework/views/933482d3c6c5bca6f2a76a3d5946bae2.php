
<a href="<?php echo e(url('/courses')); ?>" class="brand-logo hide-on-med-and-down">
    <img src="<?php echo e(asset('img/logo-curso.svg')); ?>" alt="logo-curso">
</a>


<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>


<ul class="right hide-on-med-and-down">
    
    <li><a href="<?php echo e(route('courses.index')); ?>">Cursos</a></li>
    <li><a href="<?php echo e(route('pages.about')); ?>">Sobre</a></li>

    <?php if(auth()->guard()->guest()): ?> 
        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
        <li><a href="<?php echo e(route('register')); ?>">Registro</a></li>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?> 
        <li><a href="<?php echo e(route('dashboard')); ?>" <?php if(request()->routeIs('dashboard')): ?> class="active" <?php endif; ?>>Dashboard</a></li>

        
        <li>
            <a class="dropdown-trigger" href="#!" data-target="userDropdown">
                <?php echo e(Auth::user()->name); ?><i class="material-icons right">arrow_drop_down</i>
            </a>
        </li>
    <?php endif; ?>
</ul>


<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Inicializa o Dropdown
            var dropdownElems = document.querySelectorAll('.dropdown-trigger');
            M.Dropdown.init(dropdownElems, {
                constrainWidth: false
            });

            // Inicializa o Sidenav
            var sidenavElems = document.querySelectorAll('.sidenav');
            M.Sidenav.init(sidenavElems);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\Plataforma_ADBelem\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>