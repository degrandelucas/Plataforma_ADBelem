<!DOCTYPE html>
<html>
    <head>
        <title>Lista de Cursos</title>
    </head>
    <body>
         

        <?php $__env->startSection('title', 'Lista de Cursos'); ?> 

        <?php $__env->startSection('content'); ?> 
        <h1 class="center-align">Todos os Cursos Publicados</h1>

        <?php if(isset($courses) && $courses->count() > 0): ?>
            <div class="collection"> 
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('courses.show', $course->id)); ?>" class="collection-item menu-item">
                        <?php echo e($course->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="card-panel teal lighten-2 white-text">Não há cursos publicados no momento.</div> 
        <?php endif; ?>
        <?php $__env->stopSection(); ?> 
    </body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Plataforma_ADBelem\resources\views/courses/index.blade.php ENDPATH**/ ?>