<!DOCTYPE html>
<html>
    <head>
        <title>Detalhes do Curso: <?php echo e($course->name ?? 'Curso não encontrado'); ?></title>
    </head>
    <body>
        

        <?php $__env->startSection('title', $course->name ?? 'Curso não encontrado'); ?>

        <?php $__env->startSection('content'); ?>
        <?php if(isset($course)): ?>
            <h1 class="center-align"><?php echo e($course->name); ?></h1>

            <?php if($course->thumbnail): ?>
                <img src="<?php echo e($course->thumbnail); ?>" class="responsive-img z-depth-1" alt="Capa do Curso">
            <?php endif; ?>

            <div class="card">
                <div class="card-content">
                    <span class="card-title">Descrição:</span>
                    <p><?php echo e($course->description); ?></p>
                </div>
            </div>

            <h2 class="center-align">Módulos do Curso</h2>
            <?php if($course->modules->count() > 0): ?>
                <div class="collection">
                    <?php $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="collection-item">
                            <h5><?php echo e($module->order); ?>. <?php echo e($module->name); ?></h5>
                            <p>Descrição: <?php echo e($module->description); ?></p>
                            <?php if($module->video_url): ?>
                                <p>Link do Vídeo: <a href="<?php echo e($module->video_url); ?>" target="_blank">Assistir Vídeo</a></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="card-panel orange lighten-2 white-text">Este curso ainda não possui módulos.</div>
            <?php endif; ?>

            <br>
            <a href="<?php echo e(url('/courses')); ?>" class="waves-effect waves-light btn #004d40 teal darken-4"><i class="material-icons left">arrow_back</i>Voltar para a lista de cursos</a>
        <?php else: ?>
            <div class="card-panel red lighten-1 white-text">Curso não encontrado.</div>
        <?php endif; ?>
        <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Plataforma_ADBelem\resources\views/courses/show.blade.php ENDPATH**/ ?>